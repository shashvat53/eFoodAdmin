import React from 'react'

const EmployeeJson = () => {
    const Employee  = [
        {
          SL: 1,
          Name: "John Smith",
          Contact: "123-456-7890",
          Role: "Chef",
          Status: "Active",
          Action: "Edit"
        },
        {
          SL: 2,
          Name: "Alice Johnson",
          Contact: "987-654-3210",
          Role: "Server",
          Status: "Active",
          Action: "Delete"
        },
        {
          SL: 3,
          Name: "David Brown",
          Contact: "456-789-0123",
          Role: "Bartender",
          Status: "Inactive",
          Action: "Edit"
        },
        {
          SL: 4,
          Name: "Mary Williams",
          Contact: "789-012-3456",
          Role: "Host/Hostess",
          Status: "Active",
          Action: "Edit"
        },
        {
          SL: 5,
          Name: "Emma Davis",
          Contact: "321-654-9870",
          Role: "Manager",
          Status: "Active",
          Action: "Delete"
        }
      ];
      
      
  return (
    Employee
  )
}

export default EmployeeJson
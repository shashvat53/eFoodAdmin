import React from 'react'

const CurrencyJson = () => {
    const currencies = [
        "USD", // United States Dollar
        "EUR", // Euro
        "GBP", // British Pound Sterling
        "JPY", // Japanese Yen
        "AUD", // Australian Dollar
        "CAD", // Canadian Dollar
        "CHF", // Swiss Franc
        "CNY", // Chinese Yuan
        "SEK", // Swedish Krona
        "NZD", // New Zealand Dollar
        "KRW", // South Korean Won
        "INR", // Indian Rupee
        "RUB", // Russian Ruble
        "BRL", // Brazilian Real
        "TRY", // Turkish Lira
        "ZAR", // South African Rand
        "AED", // United Arab Emirates Dirham
        "HKD", // Hong Kong Dollar
        "SGD", // Singapore Dollar
        "MXN", // Mexican Peso
      ];
      
      
  return (
    currencies
  )
}

export default CurrencyJson
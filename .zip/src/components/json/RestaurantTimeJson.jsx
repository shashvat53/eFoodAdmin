import React from 'react'

const RestaurantTimeJson = () => {
    const time = [
        {
          title1: "Monday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Tuesday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Wednesday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Thursday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Friday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Saturday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        },
        {
          title1: "Sunday",
          card:[
            {
              title2:'Opening Time',
              time:'08:00:00 AM'
            },
            {
              title2:'Closing Time',
              time:'08:00:00 PM'
            },
          ]
        }
      ];
      
      
  return (
    time
  )
}

export default RestaurantTimeJson
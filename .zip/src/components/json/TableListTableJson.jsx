import React from 'react'

const TableListTableJson = () => {
    const dummyData = [
        {
          TableNumber: 1,
          TableCapacity: 4,
          Branch: "Branch A",
          Status: true
        },
        {
          TableNumber: 2,
          TableCapacity: 6,
          Branch: "Branch A",
          Status: false
        },
        {
          TableNumber: 1,
          TableCapacity: 4,
          Branch: "Branch B",
          Status: true
        },
        {
          TableNumber: 2,
          TableCapacity: 6,
          Branch: "Branch B",
          Status: true
        },
        {
          TableNumber: 3,
          TableCapacity: 4,
          Branch: "Branch B",
          Status: false
        }
      ];
      
      
  return (
    dummyData
  )
}

export default TableListTableJson
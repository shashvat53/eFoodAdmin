import React from 'react'

const AddOnJosn = () => {
    const foodAddons = [
        {
          name: "Extra Cheese",
          price: 1.50,
          tax: 0.15
        },
        {
          name: "Bacon Strips",
          price: 2.00,
          tax: 0.20
        },
        {
          name: "Avocado",
          price: 1.75,
          tax: 0.18
        },
        {
          name: "Grilled Onions",
          price: 1.25,
          tax: 0.13
        },
        {
          name: "Fried Egg",
          price: 1.80,
          tax: 0.18
        }
      ];
      
      
  return (
    foodAddons
  )
}

export default AddOnJosn
import React from "react";
import SearchBox from "../../components/ui/SearchBox";
import EmployeeRoleSetupTable from "../../components/ui/table/EmployeeRoleSetupTable";

const EmployeeRoleSetup = () => {
  return (
    <div>
      <h1 className="text-2xl font-semibold pl-3 my-3">
        <i className="ri-user-line text-red-400 font-semibold"></i> Employee
        Role Setup
      </h1>
      <div>
        <form action="">
          <h1 className="font-semibold pl-3">Role Form</h1>
          <div className="w-full flex flex-col min-h-fit rounded-xl overflow-hidden border shadow-lg pb-4 pt-5 mb-5">
            <div className=" w-full h-1/2  md:h-full px-5 py-2">
              <label htmlFor="Title">
                Role Name <span className="text-red-500"> </span>
              </label>
              <input
                type="text"
                placeholder="Ex. Store"
                className="w-full px-2 py-2 mt-2 rounded-md border mb-4 "
              />
            </div>
            <div>
              <div className="flex  gap-2 p-5">
                <div className="flex flex-col gap-2">
                  <div className="w-fit gap-2 flex" >
                <p className="font-semibold">Module Permission :</p>
                     <input
                    type="checkbox"
                    name="SelectAll"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Select All
                  </div>
                  <div className="grid grid-flow-row grid-cols-1 sm:grid-cols-2 md:grid-cols-3 pl-5 lg:grid-cols-4  gap-5">
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="DashboardManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Dashboard Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="PosManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Pos Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="OrderManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Order Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="ProductManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Product Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="PromotionManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Promotion Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="HelpAndSupportManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Help And Support Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="ReportAndAnalyticsManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Report And Analytics Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="UserManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> User Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="TableManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> Table Management
                  </div>
                    {/* ------ */}
                  <div className="w-full gap-2 flex" >
                     <input
                    type="checkbox"
                    name="SystemManagement"
                    placeholder="Ex. Store"
                    className=" px-2 py-2 mt-2 rounded-md border mb-4 "
                  /> System Management
                  </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
          <div className="my-10  w-full flex items-center justify-end">
            <button className="px-10 border-none rounded py-3 bg-gray-300">
              Reset
            </button>
            <button className="px-10 border-none rounded ml-4  py-3 bg-[#E35F4E] text-white">
              Submit
            </button>
          </div>
        </form>
      </div>
      <div className='flex gap-2 justify-between items-center p-3 flex-wrap'>
      <SearchBox/>
      
      <button className='border-red-400 hover:bg-red-400 hover:text-white border-2 px-4 py-2 rounded-md text-red-400 flex items-center justify-center gap-2'>
      <i className="ri-download-2-line"></i>
        Export
        <i className="ri-arrow-drop-down-line"></i>
        </button>
    </div>
    <div className="overflow-x-auto">
        <EmployeeRoleSetupTable/>
    </div>
    </div>
  );
};

export default EmployeeRoleSetup;


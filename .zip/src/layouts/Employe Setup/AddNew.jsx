import React from "react";

const AddNew = () => {
  return (
    <div
      className="py-4 px-4 sm:px-6 lg:px-8
    "
    >
      <div className="flex flex-wrap gap-2 items-center ">
        <h2 className="text-xl mb-0 flex items-center gap-4">
          <img
            width="20"
            className="avatar-img"
            src="https://efood-admin.6amtech.com/public/assets/admin/img/icons/employee.png"
            alt=""
          />
          <span className="page-header-title font-semibold">
            Add New Employee
          </span>
        </h2>
      </div>

      <div className="my-5 border rounded-md ">
        <div className="flex items-center gap-3 p-[10px_20px]">
          <i className="fa-solid fa-user"></i>
          <h2>General Information</h2>
        </div>
        <hr />
        <div className=" p-[18px_20px] flex flex-col md:flex-row pb-[3rem] gap-10">
          <div className="w-full md:w-[50%]    flex flex-col gap-6">
            <div className="flex flex-col gap-1">
              <label className="block">Full Name</label>
              <input
                type="text"
                placeholder="EX: Jhon Doe"
                className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="block ">Phone</label>
              <input
                type="text"
                placeholder="EX: +91********"
                className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="block ">Role</label>
              <select className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md">
                <option>Manager</option>
                <option>Product Manager</option>
                <option>Order Manager</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="block ">Identity Type</label>
              <select className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md">
                <option disabled>---Select Identity Type---</option>
                <option>Driving License</option>
                <option>Passport</option>
                <option>NID</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="block ">Identity Number</label>
              <input
                type="text"
                className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
              />
            </div>
          </div>

          <div className="w-full md:w-[50%] ">
            <div>
              <div className="  ">
                <img
                  src="https://efood-admin.6amtech.com/public/assets/admin/img/400x400/img2.jpg"
                  className="w-[300px] md:w-[200px] mx-auto rounded-md"
                />
              </div>

              <div className="   my-6">
                <p className="my-2">
                  Employee Image{" "}
                  <span className="text-red-600">( Ratio 1:1 )</span>
                </p>
                <input
                  type="file"
                  name="image"
                  id="customFileUpload"
                  className="p-3 border rounded-tl-md  rounded-bl-md  w-[200px] md:w-[500px]"
                  accept=".jpg, .png, .jpeg, .gif, .bmp, .tif, .tiff|image/*"
                  required
                />
                <label
                  htmlFor="customFileUpload"
                  className="border p-4 border-l-0 rounded-tr-md  rounded-br-md"
                >
                  Browse
                </label>
              </div>

              <div>
                <span>Identity Image</span>
                <div className=" mt-2">
                  <img
                    src="https://efood-admin.6amtech.com/public/assets/admin/img/400x400/img2.jpg"
                    className="w-[150px] md:w-[150px] rounded-md border-2 border-dotted p-3"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="my-5 border rounded-md pb-[3rem] md:pb-[2rem]">
        <div className="flex items-center gap-3 p-[10px_20px]">
          <i className="fa-solid fa-user"></i>
          <h2>Account Information</h2>
        </div>
        <hr />
        <div className="w-full  p-[20px_20px] grid grid-flow-row grid-cols-1 md:grid-cols-3 gap-6">
          <div className="flex flex-col gap-1">
            <label className="block">Email</label>
            <input
              type="text"
              placeholder="EX: ex@gmail.com"
              className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="block ">Password</label>
            <input
              type="text"
              placeholder="EX: 8+ Character"
              className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
            />
          </div>
          <div className="flex flex-col gap-1">
            <label className="block ">Confirm Password</label>
            <input
              type="text"
              placeholder="Confirm Password"
              className="border border-gray-400 focus:border-red-500 px-4 py-2 focus:outline-none rounded-md"
            />
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <div className="flex gap-6 ">
          <button className="p-[12px_25px] bg-gray-100 rounded-md shadow-md">
            Reset
          </button>
          <button className="p-[12px_25px] bg-red-400 rounded-md shadow-md text-white">
            Submit
          </button>
        </div>
      </div>

    </div>
  );
};

export default AddNew;

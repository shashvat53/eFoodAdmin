import React from 'react'

const LanguageSetUp = () => {
  return (
    <div className='w-full h-screen '>
      <div className='w-full h-16 border-l-4 flex items-center justify-start px-5 border border-red-400 rounded bg-red-50'>
                <p><b>Note</b> :Changing some settings will take time to show effect please clear session or wait for 60 minutes else browse from incognito mode</p>
            </div>
    </div>
  )
}

export default LanguageSetUp